<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the ENEM sales page as one ordered index route with in-page offer navigation because this campaign explicitly requires one scrolling page.
- Keep offer values and persistent countdown calculations in a pure shared module with rule tests; browser storage runs only after hydration.
- Use bundled generated imagery only as product mockups or explicitly illustrative portraits; actual material previews require user-supplied assets.
