# Página de vendas
- [x] Construir as dez seções e identidade visual mobile-first.
- [x] Implementar temporizador persistente, checkout, perguntas e estrutura de ampliação de imagens.
- [x] Verificar navegação, temporizador e visual no celular e computador.
- [x] Inserir as cinco imagens reais do material na ordem enviada.
- [x] Atualizar somente cores globais e fonte para Barlow.
- [x] Corrigir somente o carrossel e verificar imagens completas em 360px, 390px e 430px.