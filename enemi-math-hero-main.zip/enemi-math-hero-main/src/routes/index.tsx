import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useRef, useState } from 'react';
import useEmblaCarousel from 'embla-carousel-react';
import { ArrowRight, BookOpen, Check, CheckCircle2, ChevronLeft, ChevronRight, Clock3, CreditCard, Download, FileText, Gift, GraduationCap, Infinity as InfinityIcon, ListChecks, LockKeyhole, MonitorSmartphone, ShieldCheck, Smartphone, Star, Target, Wallet, X, ZoomIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import portraits from '@/assets/student-portraits.jpg';
import material1 from '@/assets/material-1.png.asset.json';
import material2 from '@/assets/material-2.png.asset.json';
import material3 from '@/assets/material-3.png.asset.json';
import material4 from '@/assets/material-4.png.asset.json';
import material5 from '@/assets/material-5.png.asset.json';
import { CHECKOUT_URL, getDeadline, OFFER, remainingSeconds, TIMER_KEY } from '@/lib/offer';

export const Route = createFileRoute('/')({
  head: () => ({ meta: [
    { title: 'Matemática Direta ao Ponto — ENEM | Revisão em PDF' },
    { name: 'description', content: 'Revise a matemática do ENEM com 250+ páginas, teoria objetiva, exemplos resolvidos e 2 bônus. R$27,90 e garantia de 7 dias.' },
    { property: 'og:title', content: 'Matemática Direta ao Ponto — ENEM' },
    { property: 'og:description', content: 'Uma revisão direta e organizada por tema. PDF com 250+ páginas e 2 bônus por R$27,90.' },
    { property: 'og:type', content: 'website' },
    { name: 'twitter:card', content: 'summary_large_image' },
  ] }),
  component: Index,
});

const benefits = [
  { icon: Target, title: 'Direto ao ponto', text: 'Só o que a prova cobra, sem enrolação.' },
  { icon: ListChecks, title: 'Organizado por tema', text: 'Você abre no assunto que precisa.' },
  { icon: BookOpen, title: 'Exemplos passo a passo', text: 'Resoluções completas, no estilo ENEM.' },
  { icon: Smartphone, title: 'Estude pelo celular', text: 'Onde e quando quiser, no seu ritmo.' },
  { icon: InfinityIcon, title: 'Acesso vitalício', text: 'Baixou, é seu para sempre.' },
  { icon: Wallet, title: 'Cabe no seu bolso', text: 'Preço acessível, menos que um lanche.' },
];
const testimonials = [
  { quote: 'Eu sempre travava nas questões de porcentagem e função. Com o material organizado por tema, consegui revisar bem mais rápido.', name: 'Aluno', year: '3º ano' },
  { quote: 'Comprei sem esperar muito e me surpreendi. Os exemplos resolvidos ajudaram a entender o padrão das questões.', name: 'Treineira', year: '2º ano' },
  { quote: 'Material direto ao ponto mesmo. Uso no celular entre uma aula e outra do cursinho.', name: 'Aluna de cursinho', year: '1ª tentativa' },
];
const faqs = [
  ['Como eu recebo o material depois de comprar?', 'Assim que o pagamento for aprovado, você recebe o acesso automaticamente no e-mail usado na compra. É só baixar o PDF e começar a estudar.'],
  ['Consigo estudar pelo celular?', 'Sim! O PDF foi formatado para leitura confortável no celular e no computador, com sumário para ir direto ao tema que você precisa.'],
  ['Por quanto tempo tenho acesso?', 'O acesso é vitalício. Você baixa o material e ele é seu para sempre.'],
  ['Preciso ser bom em matemática para acompanhar?', 'Não. O material foi feito para quem sente dificuldade, com linguagem direta e exemplos resolvidos passo a passo.'],
  ['E se eu não gostar do material?', 'Você tem 7 dias de garantia incondicional. É só pedir o reembolso e devolvemos 100% do valor.'],
];
const materialImages: string[] = [material1.url, material2.url, material3.url, material4.url, material5.url];
const materialLabels = ['Sistema de numeração decimal', 'Razão e proporção', 'Matemática financeira', 'Análise combinatória', 'Função do 2º grau'];

function PurchaseButton({ children = 'Quero minha revisão por R$27,90' }: { children?: React.ReactNode }) {
  return <Button variant="purchase" asChild><a href={CHECKOUT_URL}>{children}<ArrowRight aria-hidden="true" /></a></Button>;
}
function SectionHeading({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle?: string }) {
  return <div className="section-heading"><div className="eyebrow">{eyebrow}</div><h2>{title}</h2>{subtitle && <p>{subtitle}</p>}</div>;
}
function OfferTimer() {
  const [seconds, setSeconds] = useState(OFFER.durationSeconds);
  useEffect(() => {
    const now = Date.now();
    let deadline = getDeadline(null, now);
    try { deadline = getDeadline(localStorage.getItem(TIMER_KEY), now); localStorage.setItem(TIMER_KEY, String(deadline)); } catch { /* Storage may be unavailable in private browsers. */ }
    const tick = () => setSeconds(remainingSeconds(deadline, Date.now()));
    tick(); const interval = window.setInterval(tick, 1000);
    return () => window.clearInterval(interval);
  }, []);
  const time = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  return <div className="timer-block"><Clock3 aria-hidden="true" /><span>{seconds > 0 ? 'Oferta por tempo limitado' : 'Tempo da oferta encerrado'}</span><strong role="timer" aria-label="Tempo restante da oferta">{time}</strong></div>;
}
function MaterialSlider() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });
  const [selected, setSelected] = useState(0);
  const [expanded, setExpanded] = useState<number | null>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    if (!emblaApi) return;
    const onSelect = () => setSelected(emblaApi.selectedScrollSnap());
    onSelect(); emblaApi.on('select', onSelect);
    return () => { emblaApi.off('select', onSelect); };
  }, [emblaApi]);
  function expand(index: number) { setExpanded(index); dialogRef.current?.showModal(); }
  return <>
    <div className="slider" role="region" aria-label="Exemplos do material">
    <div className="slider-viewport" ref={emblaRef}><div className="slider-track">{materialImages.map((src, index) => <div className="material-slide" key={index} role="group" aria-label={`Imagem ${index + 1} de ${materialImages.length}`}>
        <Button variant="ghost" className="preview-surface" onClick={() => expand(index)} aria-label={`Ampliar imagem ${index + 1}: ${materialLabels[index]}`}><img className="preview-image" src={src} alt={`Página do material sobre ${materialLabels[index]}`} loading="lazy" /><ZoomIn /></Button>
      </div>)}</div></div>
      <Button variant="outline" size="icon" className="slider-arrow previous" aria-label="Imagem anterior" onClick={() => emblaApi?.scrollPrev()}><ChevronLeft /></Button>
      <Button variant="outline" size="icon" className="slider-arrow next" aria-label="Próxima imagem" onClick={() => emblaApi?.scrollNext()}><ChevronRight /></Button>
      <div className="slider-dots">{materialImages.map((_, i) => <Button variant="ghost" key={i} className="dot-button" aria-label={`Ver imagem ${i + 1}`} aria-current={selected === i} onClick={() => emblaApi?.scrollTo(i)}><i /></Button>)}</div>
    </div>
    <dialog ref={dialogRef} className="lightbox" aria-label="Imagem ampliada do material" onClick={event => { if (event.target === event.currentTarget) dialogRef.current?.close(); }}>
      <Button variant="ghost" size="icon" className="lightbox-close" aria-label="Fechar imagem" onClick={() => dialogRef.current?.close()}><X /></Button>
      {expanded !== null && materialImages[expanded] && <img src={materialImages[expanded]} alt={`Página ${expanded + 1} ampliada`} />}
    </dialog>
  </>;
}
function Index() {
  const pageRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const elements = pageRef.current?.querySelectorAll('.reveal');
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.remove('reveal-pending'); observer.unobserve(entry.target); }
    }), { threshold: 0.08 });
    elements?.forEach(el => { if (el.getBoundingClientRect().top > window.innerHeight) el.classList.add('reveal-pending'); observer.observe(el); });
    return () => observer.disconnect();
  }, []);
  return <div ref={pageRef}>
    <header className="site-header container"><a href="/" className="wordmark" aria-label="Matemática Direta ao Ponto — ENEM">MATEMÁTICA DIRETA AO PONTO<span>REVISÃO ENEM · SIMPLES. OBJETIVA. SUA.</span></a><div className="header-note"><ShieldCheck /> Compra 100% segura</div></header>
    <main>
      <section className="hero" aria-labelledby="hero-title">
        <div className="hero-content container"><div className="hero-copy"><div className="eyebrow">Sua próxima revisão começa aqui</div>
          <h1 id="hero-title">Pare de perder pontos fáceis de matemática no ENEM</h1>
          <p>Uma revisão direta, sem enrolação e organizada por tema, com mais de 250 páginas para você estudar pelo celular.</p>
          <Button variant="purchase" asChild><a href="#oferta">Quero minha revisão agora<ArrowRight aria-hidden="true" /></a></Button>
          <div className="hero-proof"><span><FileText />250+ páginas</span><span><Download />Acesso imediato</span><span><ShieldCheck />7 dias de garantia</span></div>
        </div></div>
      </section>
      <section className="section"><div className="container reveal"><SectionHeading eyebrow="Seu estudo, mais simples" title="O que você vai receber" />
        <div className="receive-grid"><div className="receive-card"><div className="receive-icon"><BookOpen /></div><h3>Revisão completa<span>250+ páginas</span></h3><p>Todo o conteúdo de matemática do ENEM dividido por tema, com teoria objetiva, exemplos resolvidos e o que mais cai em cada assunto.</p></div>
          <div className="feature-list">{['Sumário navegável: vá direto ao tema', 'Linguagem direta e fácil de entender', 'PDF no celular e no computador', 'Teoria objetiva + exemplos resolvidos'].map(text => <div className="feature-line" key={text}><CheckCircle2 />{text}</div>)}</div>
        </div></div></section>
      <section className="section soft"><div className="container reveal"><SectionHeading eyebrow="Menos enrolação. Mais matemática." title="Por que escolher o Matemática Direta ao Ponto?" />
        <div className="benefit-grid">{benefits.map(({ icon: Icon, title, text }) => <article className="benefit-card" key={title}><Icon className="benefit-icon" /><h3>{title}</h3><p>{text}</p></article>)}</div>
      </div></section>
      <section className="section"><div className="container reveal"><SectionHeading eyebrow="Um reforço extra para sua prova" title="Você também leva 2 bônus" />
        <div className="bonus-grid"><article className="bonus-card"><div className="bonus-tag"><Gift size={13} />BÔNUS 01</div><FileText /><h3>Cola de véspera com fórmulas</h3><p>Resumo de bolso com as fórmulas essenciais para revisar no dia anterior e nas últimas horas antes da prova.</p></article>
        <article className="bonus-card"><div className="bonus-tag"><Gift size={13} />BÔNUS 02</div><GraduationCap /><h3>Lista de questões comentadas</h3><p>Questões no estilo ENEM com resolução comentada passo a passo, para treinar a aplicação.</p></article></div>
      </div></section>
      <section id="oferta" className="offer-section"><div className="container reveal"><div className="eyebrow">Tudo o que você precisa para revisar</div><h2>Sua revisão completa.<br />Um investimento pequeno.</h2>
        <div className="offer-card"><ul className="offer-includes"><li><Check />Revisão completa — 250+ páginas</li><li><Check />Bônus 01: Cola de véspera com fórmulas</li><li><Check />Bônus 02: Lista de questões comentadas</li></ul>
          <div className="price-block"><p className="old-price">De <s>R$67</s> por apenas</p><p className="new-price"><small>R$</small>27,90</p><p className="price-note">Pagamento único · Acesso vitalício</p></div>
          <OfferTimer /><PurchaseButton />
          <div className="payment-options"><span><Wallet />Pix</span><span><CreditCard />Cartão de crédito</span><span><CreditCard />Cartão de débito</span></div><p className="secure-note"><LockKeyhole />Pagamento seguro via Kirvano</p>
        </div>
      </div></section>
      <section className="section"><div className="container reveal"><SectionHeading eyebrow="Por dentro da sua revisão" title="Veja como é o material por dentro" /><MaterialSlider /></div></section>
      <section className="section soft"><div className="container reveal"><SectionHeading eyebrow="Cada revisão, um passo à frente" title="Quem já revisou com o material" />
        <div className="testimonial-grid">{testimonials.map((t, i) => <article className="testimonial-card" key={t.name}><div className="stars" aria-label="5 de 5 estrelas">{Array.from({ length: 5 }, (_, j) => <Star key={j} />)}</div><blockquote>“{t.quote}”</blockquote><div className="student"><div className={`portrait portrait-${i}`}><img src={portraits} width={1536} height={512} loading="lazy" alt="Retrato ilustrativo" /></div><div><strong>{t.name}</strong><span>{t.year}</span></div></div></article>)}</div>
        <p className="illustrative-note">Depoimentos fornecidos para esta página. Fotos ilustrativas; não retratam os autores.</p>
      </div></section>
      <section className="section"><div className="container reveal"><div className="guarantee-inner"><div className="guarantee-seal"><ShieldCheck aria-hidden="true" /><strong>7<span>DIAS</span></strong></div><h2>Garantia incondicional de 7 dias</h2><p>Baixe, leia e teste o material. Se em até 7 dias você achar que não é para você, devolvemos 100% do valor, sem justificativa e sem burocracia. O risco é nosso.</p><PurchaseButton /></div></div></section>
      <section className="section soft"><div className="container reveal"><SectionHeading eyebrow="Pode perguntar" title="Perguntas frequentes" /><Accordion type="single" collapsible className="faq">{faqs.map(([q, a], i) => <AccordionItem key={q} value={`faq-${i}`}><AccordionTrigger className="faq-trigger">{q}</AccordionTrigger><AccordionContent className="faq-answer">{a}</AccordionContent></AccordionItem>)}</Accordion></div></section>
    </main><footer>© 2026 Sua Marca. Todos os direitos reservados.</footer>
  </div>;
}
