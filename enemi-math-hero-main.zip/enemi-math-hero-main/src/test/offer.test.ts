import { describe, expect, it } from 'vitest';
import { CHECKOUT_URL, getDeadline, OFFER, remainingSeconds } from '../lib/offer';
describe('ENEM offer rules', () => {
  it('costs R$27.90 instead of R$67', () => {
    expect(OFFER.price).toBe(27.9);
    expect(OFFER.original).toBe(67);
  });
  it('offers a seven-day guarantee', () => expect(OFFER.guaranteeDays).toBe(7));
  it('starts with fifteen minutes', () => expect(getDeadline(null, 1000)).toBe(901000));
  it('preserves the existing deadline after reload', () => expect(getDeadline('901000', 100000)).toBe(901000));
  it('does not restart expired offers', () => expect(remainingSeconds(getDeadline('1000', 2000), 2000)).toBe(0));
  it('uses the supplied checkout', () => expect(CHECKOUT_URL).toBe('https://pay.kirvano.com/f362a5ab-9127-46b6-8907-73d296150e0e'));
});