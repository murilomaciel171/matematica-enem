export const CHECKOUT_URL = 'https://pay.kirvano.com/f362a5ab-9127-46b6-8907-73d296150e0e';
export const OFFER = { original: 67, price: 27.9, durationSeconds: 15 * 60, guaranteeDays: 7 };
export const TIMER_KEY = 'matematica-enem-offer-deadline';
export function getDeadline(stored: string | null, now: number) {
  const parsed = stored === null ? NaN : Number(stored);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : now + OFFER.durationSeconds * 1000;
}
export function remainingSeconds(deadline: number, now: number) {
  return Math.max(0, Math.ceil((deadline - now) / 1000));
}