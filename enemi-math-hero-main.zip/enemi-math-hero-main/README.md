# Enemi Math Hero

“Crie uma landing page de vendas completa, responsiva e mobile-first (a maior parte do tráfego virá de anúncios do Meta Ads, acessados pelo celular) para um infoproduto digital chamado ‘Matemática Direta ao Ponto — ENEM’: uma revisão em PDF com mais de 250 páginas dos conteúdos de matemática que mais caem no ENEM, organizada por tema.

A página deve seguir exatamente esta estrutura, nesta ordem:

 

1ª Seção — Topo (Hero)

Título forte: ‘Pare de perder pontos fáceis de matemática no ENEM’.

Subtítulo: ‘Uma revisão direta, sem enrolação e organizada por tema, com mais de 250 páginas para você estudar pelo celular.’

Botão de destaque (‘Quero minha revisão agora’) que rola suavemente (smooth scroll) até a Seção de Oferta (5ª seção).

 

2ª Seção — O que você vai receber

Título: ‘O que você vai receber’.

Card de destaque com o texto: ‘Revisão completa — 250+ páginas. Todo o conteúdo de matemática do ENEM dividido por tema, com teoria objetiva, exemplos resolvidos e o que mais cai em cada assunto.’

Complementar com 3 ou 4 itens curtos (ex: sumário navegável, linguagem direta, acesso em PDF no celular e no computador).

 

3ª Seção — Por que escolher nosso material?

Título: ‘Por que escolher o Matemática Direta ao Ponto?’.

Cards com ícones, cada um com um benefício:

Direto ao ponto: só o que a prova cobra, sem enrolação
Organizado por tema: você abre no assunto que precisa
Exemplos resolvidos passo a passo, no estilo ENEM
Estude pelo celular, onde e quando quiser
Acesso vitalício: baixou, é seu para sempre
Preço acessível, menos que um lanche

 

4ª Seção — Bônus

Título: ‘Você também leva 2 bônus’.

Dois cards lado a lado (empilhados no mobile):

Bônus 01: Cola de véspera com fórmulas — resumo de bolso com as fórmulas essenciais para revisar no dia anterior e nas últimas horas antes da prova
Bônus 02: Lista de questões comentadas — questões no estilo ENEM com resolução comentada passo a passo, para treinar a aplicação

 

5ª Seção — Oferta (com id='oferta' para o scroll do botão do topo)

Mostrar o preço de R$67 riscado e R$27,90 em grande destaque, pagamento único, acesso vitalício.

Incluir a lista do que vem na oferta: revisão completa 250+ páginas + Bônus 01 + Bônus 02.

Incluir um temporizador regressivo de 15 minutos em destaque acima do botão, com minutos e segundos. O tempo deve ser guardado no navegador do visitante (localStorage) para não reiniciar ao recarregar a página. Texto próximo ao timer: ‘Oferta por tempo limitado’.

Botão grande de compra (‘Quero minha revisão por R$27,90’) apontando para: https://pay.kirvano.com/f362a5ab-9127-46b6-8907-73d296150e0e

Abaixo do botão, formas de pagamento: Pix, cartão de crédito e cartão de débito.

 

6ª Seção — Exemplos do material

Título: ‘Veja como é o material por dentro’.

Carrossel (slider) com 5 imagens, com setas de navegação, indicadores de posição (bolinhas) e suporte a deslizar com o dedo no mobile. Usar as 5 imagens que vou enviar junto com este prompt, na ordem em que forem enviadas. Cada imagem deve poder ser ampliada ao clicar.

 

7ª Seção — Depoimentos

Título: ‘Quem já revisou com o material’.

3 cards de depoimento em texto, com nome, série e estrelas. com fotos de pessoas:

‘Eu sempre travava nas questões de porcentagem e função. Com o material organizado por tema, consegui revisar bem mais rápido.’ — Aluno, 3º ano
‘Comprei sem esperar muito e me surpreendi. Os exemplos resolvidos ajudaram a entender o padrão das questões.’ — Treineira, 2º ano
‘Material direto ao ponto mesmo. Uso no celular entre uma aula e outra do cursinho.’ — Aluna de cursinho, 1ª tentativa

 

8ª Seção — Garantia

Selo de garantia + título ‘Garantia incondicional de 7 dias’.

Texto: ‘Baixe, leia e teste o material. Se em até 7 dias você achar que não é para você, devolvemos 100% do valor, sem justificativa e sem burocracia. O risco é nosso.’

Botão de compra repetido logo abaixo, com o mesmo link do checkout.

 

9ª Seção — Perguntas frequentes

Accordion com 5 perguntas, todas com a resposta visível ao expandir:

Como eu recebo o material depois de comprar? ‘Assim que o pagamento for aprovado, você recebe o acesso automaticamente no e-mail usado na compra. É só baixar o PDF e começar a estudar.’
Consigo estudar pelo celular? ‘Sim! O PDF foi formatado para leitura confortável no celular e no computador, com sumário para ir direto ao tema que você precisa.’
Por quanto tempo tenho acesso? ‘O acesso é vitalício. Você baixa o material e ele é seu para sempre.’
Preciso ser bom em matemática para acompanhar? ‘Não. O material foi feito para quem sente dificuldade, com linguagem direta e exemplos resolvidos passo a passo.’
E se eu não gostar do material? ‘Você tem 7 dias de garantia incondicional. É só pedir o reembolso e devolvemos 100% do valor.’

 

10ª Seção — Rodapé

Rodapé simples, centralizado, com o texto: ‘© 2026 Sua Marca. Todos os direitos reservados.’

 

Estilo visual:

Design moderno e confiável, com azul-marinho (
#1a2c56) como cor primária e laranja/âmbar como cor de destaque nos botões. Tipografia bold e legível, seções bem espaçadas, botões grandes e com alto contraste, visual limpo e sem elementos infantis. Animações sutis de entrada ao rolar a página. Otimizar para carregamento rápido no celular.”

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/2bb3c538-b0f6-4ad3-b5c4-a78f59aa0220).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
